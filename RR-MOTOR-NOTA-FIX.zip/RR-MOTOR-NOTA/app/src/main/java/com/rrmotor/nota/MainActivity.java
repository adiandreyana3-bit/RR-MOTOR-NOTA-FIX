package com.rrmotor.nota;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {

    private static final int REQUEST_BLUETOOTH = 1001;
    private static final String PREF_NAME = "RR_MOTOR_NOTA";
    private static final String KEY_HISTORY = "HISTORY";
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final Charset PRINTER_CHARSET = Charset.forName("ISO-8859-1");

    private LinearLayout itemContainer;
    private TextView totalText, sisaText, statusText;
    private EditText namaInput, waInput, tanggalInput, motorInput, dpInput;
    private SharedPreferences prefs;
    private long editingTimestamp = -1;
    private String pendingBluetoothText;
    private String statusPembayaran = "BELUM LUNAS";

    private final NumberFormat rupiah =
            NumberFormat.getCurrencyInstance(new Locale("id", "ID"));

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        bersihkanRiwayatLama();
        tampilkanAplikasi();
    }

    private void tampilkanAplikasi() {
        editingTimestamp = -1;
        statusPembayaran = "BELUM LUNAS";

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout utama = new LinearLayout(this);
        utama.setOrientation(LinearLayout.VERTICAL);
        utama.setPadding(18, 12, 18, 24);
        scroll.addView(utama);

        TextView judul = label("🏍️ RR MOTOR NOTA", 22, true);
        judul.setGravity(Gravity.CENTER);
        utama.addView(judul);

        TextView sub = label("Nota Servis & Penjualan", 14, false);
        sub.setGravity(Gravity.CENTER);
        utama.addView(sub);

        namaInput = buatInput("Nama pelanggan *", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        utama.addView(namaInput);

        waInput = buatInput("No. WhatsApp *", InputType.TYPE_CLASS_PHONE);
        utama.addView(waInput);

        tanggalInput = buatInput("Tanggal nota *", InputType.TYPE_CLASS_TEXT);
        tanggalInput.setFocusable(false);
        tanggalInput.setClickable(true);
        tanggalInput.setOnClickListener(v -> pilihTanggal());
        utama.addView(tanggalInput);

        motorInput = buatInput("Tipe motor (opsional)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        utama.addView(motorInput);

        TextView it = label("🧾 DAFTAR BARANG / JASA", 17, true);
        it.setPadding(0, 12, 0, 4);
        utama.addView(it);

        itemContainer = new LinearLayout(this);
        itemContainer.setOrientation(LinearLayout.VERTICAL);
        utama.addView(itemContainer);

        Button tambah = buatTombol("+ TAMBAH BARANG / JASA");
        tambah.setOnClickListener(v -> tambahBarisItem());
        utama.addView(tambah);

        totalText = buatHasilText("TOTAL: Rp0");
        utama.addView(totalText);

        dpInput = buatInput("Uang Muka / DP", InputType.TYPE_CLASS_NUMBER);
        utama.addView(dpInput);

        sisaText = buatHasilText("SISA PEMBAYARAN: Rp0");
        utama.addView(sisaText);

        statusText = buatHasilText("STATUS: BELUM LUNAS");
        utama.addView(statusText);

        Button status = buatTombol("💰 UBAH STATUS PEMBAYARAN");
        status.setOnClickListener(v -> pilihStatus());
        utama.addView(status);

        Button simpan = buatTombol("💾 SIMPAN NOTA");
        simpan.setOnClickListener(v -> simpanNota());
        utama.addView(simpan);

        Button cetak = buatTombol("🖨️ CETAK NOTA");
        cetak.setOnClickListener(v -> cetakBluetoothSekarang());
        utama.addView(cetak);

        Button riwayat = buatTombol("📚 LIHAT RIWAYAT NOTA");
        riwayat.setOnClickListener(v -> tampilkanRiwayat());
        utama.addView(riwayat);

        Button wa = buatTombol("📱 KIRIM VIA WHATSAPP");
        wa.setOnClickListener(v -> kirimWhatsApp());
        utama.addView(wa);

        tambahBarisItem();
        setContentView(scroll);

        scroll.post(() -> scroll.scrollTo(0, 0));
    }

    private TextView label(String text, float size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(Color.BLACK);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, 5, 0, 5);
        return t;
    }

    private EditText buatInput(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.DKGRAY);
        e.setTextColor(Color.BLACK);
        e.setTextSize(16);
        e.setInputType(type);
        e.setSingleLine(true);
        e.setMinHeight(dp(52));
        e.setPadding(dp(10), dp(4), dp(10), dp(4));
        e.setBackgroundResource(android.R.drawable.edit_text);
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(-1, dp(54));
        lp.setMargins(0, dp(3), 0, dp(3));
        e.setLayoutParams(lp);
        e.setOnClickListener(v -> {
            if (e.isFocusable()) {
                e.requestFocus();
                ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                        .showSoftInput(e, InputMethodManager.SHOW_IMPLICIT);
            }
        });
        return e;
    }

    private int dp(int n) {
        return (int)(n * getResources().getDisplayMetrics().density + .5f);
    }

    private Button buatTombol(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setMinHeight(dp(48));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.setMargins(0, dp(3), 0, dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    private TextView buatHasilText(String text) {
        TextView t = label(text, 17, true);
        t.setPadding(0, dp(7), 0, dp(7));
        return t;
    }

    private void pilihTanggal() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (v,y,m,d) -> {
            Calendar x = Calendar.getInstance();
            x.set(y,m,d);
            tanggalInput.setText(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(x.getTime()));
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void tambahBarisItem() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(4), 0, dp(5));

        EditText nama = buatInput("Nama barang / jasa", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        EditText jumlah = buatInput("Jumlah", InputType.TYPE_CLASS_NUMBER);
        EditText harga = buatInput("Harga satuan", InputType.TYPE_CLASS_NUMBER);

        TextView sub = buatHasilText("Subtotal: Rp0");
        sub.setTextSize(14);

        Button hapus = buatTombol("❌ Hapus item");
        row.addView(nama); row.addView(jumlah); row.addView(harga); row.addView(sub); row.addView(hapus);
        itemContainer.addView(row);

        View.OnFocusChangeListener l = (v, f) -> { if (!f) hitungTotal(); };
        jumlah.setOnFocusChangeListener(l);
        harga.setOnFocusChangeListener(l);

        nama.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ hitungTotal(); }
            public void afterTextChanged(android.text.Editable e){}
        });
        jumlah.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ hitungTotal(); }
            public void afterTextChanged(android.text.Editable e){}
        });
        harga.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ hitungTotal(); }
            public void afterTextChanged(android.text.Editable e){}
        });

        hapus.setOnClickListener(v -> {
            itemContainer.removeView(row);
            if (itemContainer.getChildCount() == 0) tambahBarisItem();
            hitungTotal();
        });
    }

    private long angka(EditText e) {
        if (e == null) return 0;
        String s = e.getText().toString().replace(".","").replace(",","").trim();
        if (s.isEmpty()) return 0;
        try { return Long.parseLong(s); } catch(Exception ex) { return 0; }
    }

    private long hitungTotal() {
        long total = 0;
        if (itemContainer != null) {
            for (int i=0;i<itemContainer.getChildCount();i++) {
                View v=itemContainer.getChildAt(i);
                if (!(v instanceof LinearLayout)) continue;
                LinearLayout r=(LinearLayout)v;
                if (r.getChildCount()<5) continue;
                EditText q=(EditText)r.getChildAt(1);
                EditText h=(EditText)r.getChildAt(2);
                TextView s=(TextView)r.getChildAt(3);
                long sub=angka(q)*angka(h);
                s.setText("Subtotal: "+formatRupiah(sub));
                total += sub;
            }
        }
        if (totalText!=null) totalText.setText("TOTAL: "+formatRupiah(total));
        long dp=angka(dpInput); if(dp>total)dp=total;
        if(sisaText!=null)sisaText.setText("SISA PEMBAYARAN: "+formatRupiah(total-dp));
        tampilkanStatus();
        return total;
    }

    private String formatRupiah(long n) {
        return rupiah.format(n).replace(",00","");
    }

    private void tampilkanStatus() {
        if(statusText!=null) statusText.setText("STATUS: "+statusPembayaran);
    }

    private void pilihStatus() {
        String[] p={"BELUM LUNAS","LUNAS"};
        int c=statusPembayaran.equals("LUNAS")?1:0;
        new AlertDialog.Builder(this).setTitle("Status Pembayaran")
                .setSingleChoiceItems(p,c,(d,w)->{statusPembayaran=p[w];tampilkanStatus();d.dismiss();})
                .setNegativeButton("BATAL",null).show();
    }

    private void simpanNota() {
        if(namaInput.getText().toString().trim().isEmpty()){toast("Nama pelanggan wajib diisi");namaInput.requestFocus();return;}
        if(waInput.getText().toString().trim().isEmpty()){toast("No. WhatsApp wajib diisi");waInput.requestFocus();return;}
        if(tanggalInput.getText().toString().trim().isEmpty()){toast("Tanggal nota wajib diisi");return;}
        if(hitungTotal()<=0){toast("Masukkan minimal satu barang/jasa");return;}

        String data=buatDataNota(editingTimestamp==-1?System.currentTimeMillis():editingTimestamp);
        String old=prefs.getString(KEY_HISTORY,"");
        if(editingTimestamp==-1){
            if(!old.isEmpty())old+="\n";
            old+=data;
        }else{
            StringBuilder sb=new StringBuilder();
            for(String line:old.split("\n",-1)){
                if(line.trim().isEmpty())continue;
                try{
                    long ts=Long.parseLong(line.split("\\|",-1)[0]);
                    if(ts==editingTimestamp){ if(sb.length()>0)sb.append("\n"); sb.append(data); }
                    else { if(sb.length()>0)sb.append("\n"); sb.append(line); }
                }catch(Exception ex){ if(sb.length()>0)sb.append("\n"); sb.append(line); }
            }
            old=sb.toString();
        }
        prefs.edit().putString(KEY_HISTORY,old).apply();
        toast(editingTimestamp==-1?"Nota berhasil disimpan":"Nota berhasil diperbarui");
        tampilkanAplikasi();
    }

    private String buatDataNota(long ts) {
        StringBuilder items=new StringBuilder();
        for(int i=0;i<itemContainer.getChildCount();i++){
            View v=itemContainer.getChildAt(i); if(!(v instanceof LinearLayout))continue;
            LinearLayout r=(LinearLayout)v; if(r.getChildCount()<5)continue;
            String n=((EditText)r.getChildAt(0)).getText().toString().trim();
            if(n.isEmpty())continue;
            if(items.length()>0)items.append(";");
            items.append(encode(n)).append("~").append(angka((EditText)r.getChildAt(1)))
                    .append("~").append(angka((EditText)r.getChildAt(2)));
        }
        long total=hitungTotal(), dp=angka(dpInput); if(dp>total)dp=total;
        return ts+"|"+encode(namaInput.getText().toString())+"|"+encode(waInput.getText().toString())
                +"|"+encode(tanggalInput.getText().toString())+"|"+encode(motorInput.getText().toString())
                +"|"+dp+"|"+items+"|"+encode(statusPembayaran);
    }

    private void tampilkanRiwayat() {
        bersihkanRiwayatLama();
        ScrollView scroll=new ScrollView(this);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(18,12,18,24);
        scroll.addView(box);
        TextView title=label("📚 RIWAYAT NOTA RR MOTOR",21,true);box.addView(title);
        Button back=buatTombol("⬅️ KEMBALI KE MENU UTAMA");back.setOnClickListener(v->tampilkanAplikasi());box.addView(back);

        String history=prefs.getString(KEY_HISTORY,"");
        if(history.trim().isEmpty()){
            box.addView(label("\nBelum ada riwayat nota.",16,false));
        }else{
            for(String data:history.split("\n",-1)){
                if(data.trim().isEmpty())continue;
                Nota n=bacaNota(data); if(n==null)continue;
                long s=Math.max(0,n.total-n.dp);
                TextView info=label("\n👤 "+n.nama+"\n📱 "+n.wa+"\n📅 "+n.tanggal+
                        "\n🏍️ "+n.motor+"\n💵 Total: "+formatRupiah(n.total)+
                        "\n💰 DP: "+formatRupiah(n.dp)+"\n💳 Sisa: "+formatRupiah(s)+
                        "\n📌 Status: "+n.status,14,false);
                box.addView(info);

                Button edit=buatTombol("✏️ EDIT NOTA");edit.setOnClickListener(v->tampilkanFormEdit(n));box.addView(edit);
                Button print=buatTombol("🖨️ CETAK NOTA INI");print.setOnClickListener(v->cetakBluetooth(n));box.addView(print);
                Button wa=buatTombol("📱 KIRIM VIA WHATSAPP");wa.setOnClickListener(v->kirimWhatsAppNota(n));box.addView(wa);
                Button del=buatTombol("🗑️ HAPUS NOTA");del.setOnClickListener(v->konfirmasiHapus(n.timestamp));box.addView(del);
            }
        }
        setContentView(scroll);
    }

    private void tampilkanFormEdit(Nota n) {
        // Reuse main form, then fill it.
        tampilkanAplikasi();
        editingTimestamp=n.timestamp;
        namaInput.setText(n.nama); waInput.setText(n.wa); tanggalInput.setText(n.tanggal); motorInput.setText(n.motor);
        dpInput.setText(String.valueOf(n.dp)); statusPembayaran=n.status;
        itemContainer.removeAllViews();
        if(n.items.isEmpty()) tambahBarisItem();
        for(Item it:n.items){
            tambahBarisItem();
            LinearLayout r=(LinearLayout)itemContainer.getChildAt(itemContainer.getChildCount()-1);
            ((EditText)r.getChildAt(0)).setText(it.nama);
            ((EditText)r.getChildAt(1)).setText(String.valueOf(it.jumlah));
            ((EditText)r.getChildAt(2)).setText(String.valueOf(it.harga));
        }
        tampilkanStatus(); hitungTotal();
    }

    private Nota bacaNota(String data) {
        try{
            String[] p=data.split("\\|",-1); if(p.length<7)return null;
            Nota n=new Nota(); n.timestamp=Long.parseLong(p[0]);n.nama=decode(p[1]);n.wa=decode(p[2]);n.tanggal=decode(p[3]);n.motor=decode(p[4]);n.dp=Long.parseLong(p[5]);
            if(!p[6].isEmpty())for(String q:p[6].split(";",-1)){
                String[] x=q.split("~",-1);if(x.length<3)continue;
                Item it=new Item();it.nama=decode(x[0]);it.jumlah=Long.parseLong(x[1]);it.harga=Long.parseLong(x[2]);it.subtotal=it.jumlah*it.harga;n.total+=it.subtotal;n.items.add(it);
            }
            n.status=(p.length>=8&&!p[7].isEmpty())?decode(p[7]):(n.dp>=n.total&&n.total>0?"LUNAS":"BELUM LUNAS");
            return n;
        }catch(Exception e){return null;}
    }

    private void konfirmasiHapus(long ts){
        new AlertDialog.Builder(this).setTitle("Hapus nota?").setMessage("Nota ini akan dihapus dari riwayat.")
                .setPositiveButton("HAPUS",(d,w)->hapusNota(ts)).setNegativeButton("BATAL",null).show();
    }

    private void hapusNota(long ts){
        StringBuilder sb=new StringBuilder();
        for(String line:prefs.getString(KEY_HISTORY,"").split("\n",-1)){
            if(line.trim().isEmpty())continue;
            try{if(Long.parseLong(line.split("\\|",-1)[0])==ts)continue;}catch(Exception ignored){}
            if(sb.length()>0)sb.append("\n");sb.append(line);
        }
        prefs.edit().putString(KEY_HISTORY,sb.toString()).apply();toast("Nota dihapus");tampilkanRiwayat();
    }

    private void cetakBluetoothSekarang(){
        if(!cekIzinBluetooth()){pendingBluetoothText=buatIsiNota();return;}
        tampilkanDaftarPrinter(buatIsiNota());
    }

    private void cetakBluetooth(Nota n){
        if(!cekIzinBluetooth()){pendingBluetoothText=buatIsiNota(n);return;}
        tampilkanDaftarPrinter(buatIsiNota(n));
    }

    private boolean cekIzinBluetooth(){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S){
            if(checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED ||
               checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQUEST_BLUETOOTH);
                return false;
            }
        }
        return true;
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){
        super.onRequestPermissionsResult(r,p,g);
        if(r!=REQUEST_BLUETOOTH)return;
        boolean ok=g.length>0;
        for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED)ok=false;
        if(ok && pendingBluetoothText!=null){
            String s=pendingBluetoothText;pendingBluetoothText=null;
            tampilkanDaftarPrinter(s);
        }else if(!ok)toast("Izin Bluetooth diperlukan.");
    }

    private void tampilkanDaftarPrinter(String isi){
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
        if(a==null){toast("HP tidak mendukung Bluetooth.");return;}
        try{
            if(!a.isEnabled()){
                startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
                toast("Aktifkan Bluetooth lalu tekan cetak lagi.");
                return;
            }
            Set<BluetoothDevice> set=a.getBondedDevices();
            if(set==null||set.isEmpty()){toast("Pasangkan printer terlebih dahulu di Pengaturan HP.");return;}
            ArrayList<BluetoothDevice> list=new ArrayList<>(set);
            String[] names=new String[list.size()];
            for(int i=0;i<list.size();i++){
                try{names[i]=list.get(i).getName();}catch(Exception e){names[i]="Printer Bluetooth";}
                if(names[i]==null||names[i].trim().isEmpty())names[i]="Printer Bluetooth";
            }
            new AlertDialog.Builder(this).setTitle("Pilih Printer Bluetooth").setItems(names,(d,w)->cetakKePrinter(list.get(w),isi))
                    .setNegativeButton("BATAL",null).show();
        }catch(SecurityException e){toast("Izin Bluetooth belum diberikan.");}
    }

    private void cetakKePrinter(BluetoothDevice device,String isi){
        toast("🔵 Menghubungkan ke printer...");
        new Thread(()->{
            boolean ok=false;String err="Koneksi gagal";
            for(int attempt=0;attempt<3&&!ok;attempt++){
                BluetoothSocket socket=null;OutputStream out=null;
                try{
                    BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
                    try{if(a.isDiscovering())a.cancelDiscovery();}catch(Exception ignored){}
                    try{
                        socket=device.createRfcommSocketToServiceRecord(SPP_UUID);
                        socket.connect();
                    }catch(Exception e){
                        try{if(socket!=null)socket.close();}catch(Exception ignored){}
                        socket=device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                        socket.connect();
                    }
                    out=socket.getOutputStream();
                    out.write(new byte[]{0x1B,0x40}); // reset
                    out.write(new byte[]{0x1B,0x61,0x00}); // left
                    out.write(isi.getBytes(PRINTER_CHARSET));
                    out.write(new byte[]{0x1B,0x64,0x06}); // feed
                    // GS V 0: full cut on ESC/POS printers that support it
                    try{out.write(new byte[]{0x1D,0x56,0x00});}catch(Exception ignored){}
                    out.flush();
                    Thread.sleep(900);
                    ok=true;
                }catch(Exception e){err=e.getMessage()!=null?e.getMessage():"Koneksi gagal";try{Thread.sleep(700);}catch(Exception ignored){}}
                finally{
                    try{if(out!=null)out.close();}catch(Exception ignored){}
                    try{if(socket!=null)socket.close();}catch(Exception ignored){}
                }
            }
            boolean result=ok;String message=err;
            runOnUiThread(()->toast(result?"✅ Nota berhasil dicetak melalui Bluetooth.":"❌ Gagal mencetak: "+message));
        }).start();
    }

    private String buatIsiNota(){
        Nota n=notaDariForm();
        return buatIsiNota(n);
    }

    private Nota notaDariForm(){
        Nota n=new Nota();n.timestamp=editingTimestamp;n.nama=namaInput.getText().toString().trim();n.wa=waInput.getText().toString().trim();
        n.tanggal=tanggalInput.getText().toString().trim();n.motor=motorInput.getText().toString().trim();n.dp=angka(dpInput);n.status=statusPembayaran;
        for(int i=0;i<itemContainer.getChildCount();i++){
            View v=itemContainer.getChildAt(i);if(!(v instanceof LinearLayout))continue;LinearLayout r=(LinearLayout)v;if(r.getChildCount()<5)continue;
            String name=((EditText)r.getChildAt(0)).getText().toString().trim();if(name.isEmpty())continue;
            Item it=new Item();it.nama=name;it.jumlah=angka((EditText)r.getChildAt(1));it.harga=angka((EditText)r.getChildAt(2));it.subtotal=it.jumlah*it.harga;n.total+=it.subtotal;n.items.add(it);
        }
        if(n.dp>n.total)n.dp=n.total;return n;
    }

    private String buatIsiNota(Nota n){
        long s=Math.max(0,n.total-n.dp);
        StringBuilder b=new StringBuilder();
        b.append("--------------------------------\nRR MOTOR\nNOTA SERVIS & PENJUALAN\n--------------------------------\n");
        b.append("Nama    : ").append(n.nama).append("\n");
        b.append("WA      : ").append(n.wa).append("\n");
        b.append("Tanggal : ").append(n.tanggal).append("\n");
        if(n.motor!=null&&!n.motor.isEmpty())b.append("Motor   : ").append(n.motor).append("\n");
        b.append("--------------------------------\n");
        for(Item it:n.items)b.append(it.nama).append("\n").append(it.jumlah).append(" x ").append(formatRupiah(it.harga)).append(" = ").append(formatRupiah(it.subtotal)).append("\n");
        b.append("--------------------------------\nTOTAL : ").append(formatRupiah(n.total)).append("\nDP    : ").append(formatRupiah(n.dp)).append("\nSISA  : ").append(formatRupiah(s)).append("\nSTATUS: ").append(n.status).append("\n--------------------------------\nTerima kasih\n\n\n");
        return b.toString();
    }

    private void kirimWhatsApp(){
        if(namaInput.getText().toString().trim().isEmpty()){toast("Nama pelanggan wajib diisi.");return;}
        String wa=waInput.getText().toString().trim();if(wa.isEmpty()){toast("No. WhatsApp wajib diisi.");return;}
        if(hitungTotal()<=0){toast("Masukkan minimal satu barang/jasa.");return;}
        kirimWhatsAppDenganIsi(wa,buatPesanWhatsApp(notaDariForm()));
    }

    private void kirimWhatsAppNota(Nota n){if(n==null||n.wa==null||n.wa.trim().isEmpty()){toast("Nomor WhatsApp tidak tersedia.");return;}kirimWhatsAppDenganIsi(n.wa,buatPesanWhatsApp(n));}

    private void kirimWhatsAppDenganIsi(String nomor,String pesan){
        String x=nomor.replaceAll("[^0-9+]","");if(x.startsWith("0"))x="62"+x.substring(1);if(x.startsWith("+"))x=x.substring(1);
        try{
            Intent i=new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://wa.me/"+x+"?text="+URLEncoder.encode(pesan,"UTF-8")));
            startActivity(i);
        }catch(Exception e){toast("WhatsApp tidak dapat dibuka.");}
    }

    private String buatPesanWhatsApp(Nota n){
        StringBuilder b=new StringBuilder();
        b.append("🏍️ *RR MOTOR*\n🧾 *NOTA SERVIS & PENJUALAN*\n\n");
        b.append("👤 Nama: ").append(n.nama).append("\n📱 WA: ").append(n.wa).append("\n📅 Tanggal: ").append(n.tanggal).append("\n");
        if(n.motor!=null&&!n.motor.isEmpty())b.append("🏍️ Motor: ").append(n.motor).append("\n");
        b.append("\n🧾 *DETAIL:*\n");
        for(Item it:n.items)b.append("• ").append(it.nama).append("\n  ").append(it.jumlah).append(" x ").append(formatRupiah(it.harga)).append(" = ").append(formatRupiah(it.subtotal)).append("\n");
        b.append("\n💵 *TOTAL: ").append(formatRupiah(n.total)).append("*\n💰 DP: ").append(formatRupiah(n.dp))
                .append("\n💳 Sisa: ").append(formatRupiah(Math.max(0,n.total-n.dp))).append("\n📌 Status: *").append(n.status)
                .append("*\n\nTerima kasih telah mempercayakan kendaraan Anda kepada *RR MOTOR*. 🙏");
        return b.toString();
    }

    private String encode(String s){try{return URLEncoder.encode(s==null?"":s,"UTF-8");}catch(Exception e){return s==null?"":s.replace("|","%7C");}}
    private String decode(String s){try{return java.net.URLDecoder.decode(s==null?"":s,"UTF-8");}catch(Exception e){return s==null?"":s;}}

    private void bersihkanRiwayatLama(){
        if(prefs==null)return;
        long batas=System.currentTimeMillis()-365L*24*60*60*1000;
        StringBuilder b=new StringBuilder();
        for(String line:prefs.getString(KEY_HISTORY,"").split("\n",-1)){
            if(line.trim().isEmpty())continue;
            try{if(Long.parseLong(line.split("\\|",-1)[0])<batas)continue;}catch(Exception e){continue;}
            if(b.length()>0)b.append("\n");b.append(line);
        }
        prefs.edit().putString(KEY_HISTORY,b.toString()).apply();
    }

    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}

    private static class Item{String nama="";long jumlah,harga,subtotal;}
    private static class Nota{long timestamp,dp,total;String nama="",wa="",tanggal="",motor="",status="BELUM LUNAS";ArrayList<Item>items=new ArrayList<>();}
}
